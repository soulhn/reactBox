import "./App.css";

function App() {
  return (
    <div className="App">
      <h1>하이</h1>
    </div>
  );
}

export default App;
